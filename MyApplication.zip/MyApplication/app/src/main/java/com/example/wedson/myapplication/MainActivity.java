package com.example.wedson.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button buttonSegundaTela;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Intanciar o botão.
        buttonSegundaTela  = (Button) findViewById(R.id.buttonSegundaTela);
        buttonSegundaTela.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Método chama segunda tela.
                chamaSegundaTela();
            }
        });
    }

    void chamaSegundaTela(){
        //Utilizando o objeto intent
        Intent intent = new Intent();
        //passando as Activitys dentro do método setClass.
        intent.setClass(MainActivity.this, SecondActivity.class);
        //passar o intent dentro do método startActivity
        startActivity(intent);
        finish();
    }
}
